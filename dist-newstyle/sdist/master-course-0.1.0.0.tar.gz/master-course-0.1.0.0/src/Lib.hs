module Lib
    ( someFunc
    ) where

lst = [1..55]

someFunc :: IO ()
someFunc = print lst 
