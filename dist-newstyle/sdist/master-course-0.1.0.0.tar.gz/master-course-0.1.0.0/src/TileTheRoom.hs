module TileTheRoom where
  
import Graphics.Gloss

main = display blank
