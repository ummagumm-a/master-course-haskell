# Changelog for master-course

## Unreleased changes
